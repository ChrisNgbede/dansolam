<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pages', function (Blueprint $table) {
            $table->string('subtitle', 500)->nullable()->after('slug');
            $table->string('hero_image_url')->nullable()->after('subtitle');
            $table->json('sections')->nullable()->after('content');
            $table->string('meta_title')->nullable()->after('sections');
            $table->string('meta_description', 500)->nullable()->after('meta_title');
        });
    }

    public function down(): void
    {
        Schema::table('pages', function (Blueprint $table) {
            $table->dropColumn(['subtitle', 'hero_image_url', 'sections', 'meta_title', 'meta_description']);
        });
    }
};
