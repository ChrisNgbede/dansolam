<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Invoice #<?php echo e($order->order_number); ?></title>
    <style>
        @page {
            margin: 0;
        }
        body {
            font-family: "DejaVu Sans", sans-serif;
            font-size: 11px;
            color: #332B3D;
            margin: 0;
            padding: 0;
            background-color: #FBFAF8;
        }

        /* ── LUXURY HEADER BANNER ── */
        .header-banner {
            background-color: <?php echo e($brandDark ?? '#17101F'); ?>;
            padding: 30px 36px;
            position: relative;
            overflow: hidden;
        }
        .header-banner::after {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 200px;
            height: 100%;
            background: linear-gradient(135deg, transparent 0%, <?php echo e($brandAccent ?? '#EC268F'); ?>22 100%);
        }
        .brand-row {
            width: 100%;
        }
        .brand-row td {
            vertical-align: middle;
        }
        .brand-logo-cell {
            width: 50%;
        }
        .brand-logo-cell img {
            max-height: 42px;
            max-width: 160px;
            object-fit: contain;
        }
        .brand-text-fallback {
            font-size: 22px;
            font-weight: bold;
            color: #F3EFF6;
            letter-spacing: 2px;
            text-transform: uppercase;
        }
        .brand-tagline {
            font-size: 9px;
            color: <?php echo e($brandGold ?? '#E5C158'); ?>;
            letter-spacing: 3px;
            text-transform: uppercase;
            font-weight: 600;
            margin-top: 4px;
        }
        .invoice-title-cell {
            width: 50%;
            text-align: right;
        }
        .invoice-title-label {
            font-size: 22px;
            font-weight: bold;
            color: #F3EFF6;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        .invoice-number {
            font-size: 11px;
            color: <?php echo e($brandGold ?? '#E5C158'); ?>;
            font-weight: 600;
            margin-top: 4px;
        }

        /* ── ACCENT STRIPE ── */
        .accent-stripe {
            height: 4px;
            background: linear-gradient(90deg, <?php echo e($brandPrimary ?? '#5D3E85'); ?> 0%, <?php echo e($brandAccent ?? '#EC268F'); ?> 50%, <?php echo e($brandGold ?? '#E5C158'); ?> 100%);
        }

        /* ── BODY CONTAINER ── */
        .invoice-body {
            padding: 30px 36px;
            background-color: #ffffff;
        }

        /* ── META DETAILS ── */
        .meta-grid {
            width: 100%;
            margin-bottom: 28px;
            border-collapse: collapse;
        }
        .meta-grid td {
            vertical-align: top;
            padding: 0;
        }
        .meta-box {
            background-color: #FAF7FC;
            border: 1px solid #EADBEE;
            border-radius: 10px;
            padding: 14px 18px;
        }
        .meta-box-title {
            font-size: 8px;
            font-weight: 800;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: <?php echo e($brandPrimary ?? '#5D3E85'); ?>;
            margin-bottom: 8px;
            padding-bottom: 5px;
            border-bottom: 1px solid #EADBEE;
        }
        .meta-box-line {
            font-size: 11px;
            color: #4A4054;
            line-height: 1.7;
        }
        .meta-box-line strong {
            color: #221B2B;
        }

        /* ── INVOICE METADATA PILLS ── */
        .meta-pills {
            margin-bottom: 20px;
        }
        .meta-pill {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-right: 6px;
        }
        .pill-date {
            background-color: #F0E8F8;
            color: <?php echo e($brandPrimary ?? '#5D3E85'); ?>;
        }
        .pill-method {
            background-color: #FFF8E6;
            color: #B25E00;
        }
        .pill-paid {
            background-color: #E6F7ED;
            color: #0E703C;
        }
        .pill-pending {
            background-color: #FFF2F0;
            color: #CC3300;
        }

        /* ── ITEMS TABLE ── */
        .section-label {
            font-size: 9px;
            font-weight: 800;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: <?php echo e($brandPrimary ?? '#5D3E85'); ?>;
            margin-bottom: 10px;
            padding-bottom: 6px;
            border-bottom: 1.5px solid #EADBEE;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
        }
        .items-table th {
            background-color: <?php echo e($brandDark ?? '#17101F'); ?>;
            color: #D8D0E2;
            padding: 10px 12px;
            text-align: left;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .items-table th:first-child {
            border-radius: 8px 0 0 0;
        }
        .items-table th:last-child {
            border-radius: 0 8px 0 0;
            text-align: right;
        }
        .items-table td {
            padding: 12px;
            border-bottom: 1px solid #F0E8F8;
            font-size: 11px;
            vertical-align: middle;
        }
        .items-table tr:last-child td {
            border-bottom: none;
        }
        .item-name {
            font-weight: 700;
            color: #221B2B;
        }
        .item-variant {
            font-size: 10px;
            color: #8C7F9B;
            margin-top: 2px;
        }
        .items-table .col-price,
        .items-table .col-qty {
            text-align: center;
        }
        .items-table .col-total {
            text-align: right;
            font-weight: 700;
            color: #221B2B;
        }

        /* ── SUMMARY / TOTALS ── */
        .summary-section {
            width: 100%;
            margin-bottom: 24px;
        }
        .summary-box {
            float: right;
            width: 280px;
            background-color: #FAF7FC;
            border: 1px solid #EADBEE;
            border-radius: 12px;
            padding: 16px 20px;
        }
        .summary-box table {
            width: 100%;
            border-collapse: collapse;
        }
        .summary-box td {
            padding: 5px 0;
            font-size: 11px;
        }
        .summary-label {
            color: #7B6E8A;
        }
        .summary-value {
            text-align: right;
            font-weight: 600;
            color: #332B3D;
        }
        .summary-discount {
            color: #0E703C;
        }
        .total-row td {
            padding-top: 12px;
            border-top: 2px solid <?php echo e($brandPrimary ?? '#5D3E85'); ?>;
            font-size: 15px;
            font-weight: 800;
        }
        .total-row .summary-label {
            color: <?php echo e($brandPrimary ?? '#5D3E85'); ?>;
        }
        .total-row .summary-value {
            color: <?php echo e($brandPrimary ?? '#5D3E85'); ?>;
        }

        /* ── TRUST SIGNALS ── */
        .trust-strip {
            clear: both;
            background-color: #FAF7FC;
            border: 1px solid #EADBEE;
            border-radius: 10px;
            padding: 14px 20px;
            text-align: center;
            font-size: 10px;
            color: #6B6274;
            font-weight: 600;
            margin-top: 30px;
            margin-bottom: 16px;
        }

        /* ── FOOTER ── */
        .footer-banner {
            background-color: <?php echo e($brandDark ?? '#17101F'); ?>;
            padding: 24px 36px;
            text-align: center;
            color: #9C90A9;
            font-size: 10px;
            line-height: 1.7;
        }
        .footer-brand {
            font-size: 12px;
            font-weight: 700;
            color: #F3EFF6;
            margin-bottom: 4px;
        }
        .footer-gold {
            color: <?php echo e($brandGold ?? '#E5C158'); ?>;
            font-weight: 600;
        }
        .footer-legal {
            font-size: 9px;
            color: #7B6E8A;
            margin-top: 8px;
        }
    </style>
</head>
<body>

    <!-- ── LUXURY HEADER BANNER ── -->
    <div class="header-banner">
        <table class="brand-row" style="width: 100%; border-collapse: collapse;">
            <tr>
                <td class="brand-logo-cell">
                    <?php if(!empty($logoUrl)): ?>
                        <img src="<?php echo e($logoUrl); ?>" alt="<?php echo e($ecommerceName); ?>" />
                    <?php else: ?>
                        <div class="brand-text-fallback"><?php echo e($ecommerceName); ?></div>
                    <?php endif; ?>
                    <div class="brand-tagline"><?php echo e($brandTagline ?? 'Luxury Skincare & Beauty Home'); ?></div>
                </td>
                <td class="invoice-title-cell">
                    <div class="invoice-title-label">Invoice</div>
                    <div class="invoice-number">#<?php echo e($order->order_number); ?></div>
                </td>
            </tr>
        </table>
    </div>

    <!-- ── GRADIENT ACCENT STRIPE ── -->
    <div class="accent-stripe"></div>

    <!-- ── MAIN BODY ── -->
    <div class="invoice-body">

        <!-- Invoice Meta Pills -->
        <div class="meta-pills">
            <span class="meta-pill pill-date">📅 <?php echo e($order->created_at->format('M d, Y')); ?></span>
            <span class="meta-pill pill-method">💳 <?php echo e(strtoupper(str_replace('_', ' ', $order->payment_method))); ?></span>
            <span class="meta-pill <?php echo e($order->payment_status === 'paid' ? 'pill-paid' : 'pill-pending'); ?>">
                <?php echo e($order->payment_status === 'paid' ? '✓ PAID' : '⏳ ' . strtoupper($order->payment_status)); ?>

            </span>
        </div>

        <!-- Billed From / Billed To -->
        <table class="meta-grid" style="width: 100%; border-collapse: separate; border-spacing: 10px 0;">
            <tr>
                <td style="width: 50%;">
                    <div class="meta-box">
                        <div class="meta-box-title">Billed From</div>
                        <div class="meta-box-line">
                            <strong><?php echo e($ecommerceName); ?></strong><br>
                            <?php if(!empty($storeAddress)): ?><?php echo e($storeAddress); ?><br><?php endif; ?>
                            <?php if(!empty($storePhone)): ?>📞 <?php echo e($storePhone); ?><br><?php endif; ?>
                            <?php if(!empty($storeEmail)): ?>✉ <?php echo e($storeEmail); ?><br><?php endif; ?>
                            <?php if(!empty($whatsappNumber)): ?>WhatsApp: <?php echo e($whatsappNumber); ?><?php endif; ?>
                        </div>
                    </div>
                </td>
                <td style="width: 50%;">
                    <div class="meta-box">
                        <div class="meta-box-title">Billed To</div>
                        <div class="meta-box-line">
                            <strong><?php echo e($order->customer_name); ?></strong><br>
                            ✉ <?php echo e($order->customer_email); ?><br>
                            <?php if(!empty($order->customer_phone)): ?>📞 <?php echo e($order->customer_phone); ?><br><?php endif; ?>
                            <?php if($order->delivery_method === 'delivery'): ?>
                                📍 <?php echo e($order->delivery_address); ?>

                                <?php if(!empty($order->delivery_city)): ?>, <?php echo e($order->delivery_city); ?><?php endif; ?>
                                <?php if(!empty($order->delivery_state)): ?>, <?php echo e($order->delivery_state); ?><?php endif; ?>
                                <?php if(!empty($order->delivery_country)): ?>, <?php echo e($order->delivery_country); ?><?php endif; ?>
                            <?php else: ?>
                                📍 Store Pickup
                            <?php endif; ?>
                        </div>
                    </div>
                </td>
            </tr>
        </table>

        <!-- ── ITEMIZED LINE ITEMS ── -->
        <div class="section-label">Order Line Items</div>
        <table class="items-table">
            <thead>
                <tr>
                    <th style="width: 45%;">Product</th>
                    <th class="col-price" style="width: 18%;">Unit Price</th>
                    <th class="col-qty" style="width: 12%;">Qty</th>
                    <th class="col-total" style="width: 25%;">Line Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="item-name"><?php echo e($item->product_name); ?></div>
                            <?php if(!empty($item->variant_label)): ?>
                                <div class="item-variant"><?php echo e($item->variant_label); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="col-price">&#8358;<?php echo e(number_format($item->price, 2)); ?></td>
                        <td class="col-qty"><?php echo e($item->quantity); ?></td>
                        <td class="col-total">&#8358;<?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- ── PRICING SUMMARY ── -->
        <div class="summary-section">
            <div class="summary-box">
                <table>
                    <tr>
                        <td class="summary-label">Subtotal</td>
                        <td class="summary-value">&#8358;<?php echo e(number_format($order->subtotal, 2)); ?></td>
                    </tr>
                    <?php if($order->discount_amount > 0): ?>
                        <tr class="summary-discount">
                            <td>Discount Applied</td>
                            <td class="summary-value" style="color: #0E703C;">- &#8358;<?php echo e(number_format($order->discount_amount, 2)); ?></td>
                        </tr>
                    <?php endif; ?>
                    <?php if(isset($order->applied_shipping) && is_array($order->applied_shipping) && count($order->applied_shipping) > 0): ?>
                        <?php $__currentLoopData = $order->applied_shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="summary-label">Shipping (<?php echo e($ship['name']); ?>)</td>
                                <td class="summary-value">&#8358;<?php echo e(number_format($ship['amount'], 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td class="summary-label">Delivery & Handling</td>
                            <td class="summary-value">&#8358;<?php echo e(number_format($order->delivery_fee, 2)); ?></td>
                        </tr>
                    <?php endif; ?>
                    <?php if(isset($order->tax_amount) && $order->tax_amount > 0): ?>
                        <tr>
                            <td class="summary-label">Tax</td>
                            <td class="summary-value">&#8358;<?php echo e(number_format($order->tax_amount, 2)); ?></td>
                        </tr>
                    <?php endif; ?>
                    <tr class="total-row">
                        <td class="summary-label">TOTAL AMOUNT</td>
                        <td class="summary-value">&#8358;<?php echo e(number_format($order->total_amount, 2)); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- ── TRUST SIGNALS ── -->
        <div class="trust-strip">
            🌿 100% Organic Botanical Extracts &nbsp;&bull;&nbsp; 🚚 Nationwide Delivery &nbsp;&bull;&nbsp; 💆 Professional Skincare
        </div>

    </div>

    <!-- ── FOOTER BANNER ── -->
    <div class="footer-banner">
        <div class="footer-brand"><?php echo e($ecommerceName); ?></div>
        <div class="footer-gold"><?php echo e($brandTagline ?? 'Luxury Skincare & Beauty Home'); ?></div>
        <div style="margin-top: 8px;">
            Thank you for choosing <?php echo e($ecommerceName); ?>. For exchanges or support, please reach us
            <?php if(!empty($whatsappNumber)): ?>
                on WhatsApp at <span class="footer-gold"><?php echo e($whatsappNumber); ?></span>
            <?php elseif(!empty($storeEmail)): ?>
                at <span class="footer-gold"><?php echo e($storeEmail); ?></span>
            <?php else: ?>
                through our store
            <?php endif; ?>.
        </div>
        <div class="footer-legal">
            &copy; <?php echo e(date('Y')); ?> <?php echo e($ecommerceName); ?>. All rights reserved. This is a system-generated invoice.
        </div>
    </div>

</body>
</html>
<?php /**PATH /Users/chrisngbede/Desktop/laravel/dansolam/resources/views/exports/invoice.blade.php ENDPATH**/ ?>