<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'slug',
        'subtitle',
        'hero_image_url',
        'content',
        'sections',
        'meta_title',
        'meta_description',
    ];

    protected $casts = [
        'sections' => 'array',
    ];
}
